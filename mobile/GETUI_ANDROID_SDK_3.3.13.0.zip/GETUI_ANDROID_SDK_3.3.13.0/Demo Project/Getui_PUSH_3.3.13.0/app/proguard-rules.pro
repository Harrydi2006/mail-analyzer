# Add project specific ProGuard rules here.
# By default, the flags in this file are appended to flags specified
# in /Users/dwelling/workspace/tools/android-sdk-macosx/tools/proguard/proguard-android.txt
# You can edit the include path and order by changing the proguardFiles
# directive in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# Add any project specific keep options here:

# If your project uses WebView with JS, uncomment the following
# and specify the fully qualified class name to the JavaScript interface
# class:
#-keepclassmembers class fqcn.of.javascript.interface.for.webview {
#   public *;
#}
-dontwarn com.igexin.**
-keep class com.igexin.** { *; }
-keep class org.json.** { *; }
-dontwarn com.getui.**
-keep class com.getui.** { *; }


# Gson 自定义数据模型的bean目录
-keep class com.google.gson.stream.** { *; }
-keepattributes EnclosingMethod
-keep class com.getui.demo.net.request.** {*;}
-keep class com.getui.demo.net.response.** {*;}